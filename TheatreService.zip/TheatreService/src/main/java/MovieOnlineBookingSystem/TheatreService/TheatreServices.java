package MovieOnlineBookingSystem.TheatreService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class TheatreServices {

	@Autowired
	private TheatreRepository repository;
	
	public Theatre addTheatre(Theatre theatre) {
		return repository.save(theatre);
	}

	public List<Theatre> getTheatre() {
		return (List<Theatre>) repository.findAll();
	}

	
	public List<Theatre> getTheatreByTheatrename(String theatrename) {
		return (List<Theatre>) repository.findByTheatrename(theatrename);
	}
	
	public void deleteByTheatreId(Integer id) {
		repository.deleteById(id);
	}
	
	public Theatre updateTheatre(Integer id,Theatre theatre) {
		theatre.setTheatreid(id);
		return repository.save(theatre);
	}
}

