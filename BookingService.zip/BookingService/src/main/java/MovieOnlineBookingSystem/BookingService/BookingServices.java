package MovieOnlineBookingSystem.BookingService;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.text.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BookingServices {

	@Autowired
	private BookingRepository bookrepository;
	@Autowired
	private ShowRepository showrepository;
	
	
	
	public List<Show> getAllShows(){
        return (List<Show>) showrepository.findAll();
    }
    
//    public Optional<Show> findShow(Integer id) {        
//        Optional<Show> show = showrepository.findById(id);
//        return show;
//    }
    
    public Show addShow(Show show) {
    	System.out.println(show.getMovieid().getMovieid());
        return showrepository.save(show);
    }
    
    public Show updateshowDetails(Integer id,Show show) {
        show.setShowid(id);
        return showrepository.save(show);
    }
    
    public Show getShow(Integer id) {
		return showrepository.findById(id).get();
	}
    
    public void deleteShow(Integer id) {      
    	showrepository.deleteById(id);        
    }

    
    public List<Show> findShowByMoive(Integer movieid) {       
        List<Show> allshows = getAllShows();
        List<Show> shows = new ArrayList<>();
        for(Show show : allshows) {
            if(show.getMovieid().getMovieid().equals(movieid)) {
                shows.add(show);
            }
        }
        return shows;     
    }
    
    public List<Show> findShowByTheatre(Integer theatreid) {       
        List<Show> allshows = getAllShows();
        List<Show> shows = new ArrayList<>();
        for(Show show : allshows) {
            if(show.getTheatreid().getTheatreid().equals(theatreid)) {
                shows.add(show);
            }
        }
        return shows;     
    }
    
    
    public Booking addBooking(Booking booking) {
        Integer seatsBooked=booking.getSeatsBooked();
        Integer showid=booking.getShowid().getShowid();
        Optional <Show> show=showrepository.findById(showid);
        Float ticketPrice=show.get().getTicketPrice();
        Integer seatsAvailable=show.get().getSeatsAvailable();
        Integer remainingseats=seatsAvailable-seatsBooked;
        show.get().setSeatsAvailable(remainingseats);
        System.out.println(remainingseats);
        System.out.println(ticketPrice);
        Float amount=(seatsBooked*ticketPrice);
        booking.setAmount(amount);
        booking.setStatus("BOOKED");
        return bookrepository.save(booking);
    }
    
    public List<Booking> getBookingsbytdate(String fromDate,String toDate){
        List<Booking> allbookings= new ArrayList<>();
        List<Booking> bookinglist= new ArrayList<>();
        bookrepository.findAll().forEach(allbookings::add);
       
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date startdate = null;
        Date enddate = null;
       
        try {
            startdate = dateFormat.parse(fromDate);
            enddate = dateFormat.parse(toDate);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
       
        for(Booking booking : allbookings){
           if(booking.getShowid().getShowDate().after(startdate)||booking.getShowid().getShowDate().before(enddate)||
                   booking.getShowid().getShowDate().equals(startdate)||booking.getShowid().getShowDate().equals(enddate)) {
               bookinglist.add(booking);
           }
        }
        return bookinglist;
       
    }

 

	
	public List<Booking> getBookings(){
		return (List<Booking>) bookrepository.findAll();
	}
	
	public Booking getBookingbyId(Integer id) {
		return bookrepository.findById(id).get();
	}
	
	public Booking deleteBooking(Integer id) {
		   
        Booking booking=getBookingbyId(id);
        Integer seatsBooked=booking.getSeatsBooked();
        Show show=booking.getShowid();
        Integer seatsAvailable=show.getSeatsAvailable();
        Integer remainingSeats=(seatsAvailable+seatsBooked);
        System.out.println(remainingSeats);
        show.setSeatsAvailable(remainingSeats);
        booking.setStatus("CANCELLED");
        return bookrepository.save(booking);
       
    }
}
