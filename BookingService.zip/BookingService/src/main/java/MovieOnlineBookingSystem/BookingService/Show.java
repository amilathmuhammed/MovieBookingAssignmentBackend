package MovieOnlineBookingSystem.BookingService;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name = "show_table")
public class Show {

	
	@Id
	@Column(name = "showid")        	    
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer showid;
	@OneToOne
	private Movie movieid;	 
	@OneToOne
	private Theatre theatreid;	
	private float ticketPrice;
	private Date showDate;
	private Time showTime;
	private int seatsAvailable;
	
	
	
	public Show() {
		super();
	}


	
	public Integer getShowid() {
		return showid;
	}



	public void setShowid(Integer showid) {
		this.showid = showid;
	}



	public Movie getMovieid() {
		return movieid;
	}



	public void setMovieid(Movie movieid) {
		this.movieid = movieid;
	}



	public Theatre getTheatreid() {
		return theatreid;
	}



	public void setTheatreid(Theatre theatreid) {
		this.theatreid = theatreid;
	}



	public float getTicketPrice() {
		return ticketPrice;
	}



	public void setTicketPrice(float ticketPrice) {
		this.ticketPrice = ticketPrice;
	}



	public Date getShowDate() {
		return showDate;
	}



	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}



	public Time getShowTime() {
		return showTime;
	}



	public void setShowTime(Time showTime) {
		this.showTime = showTime;
	}



	public int getSeatsAvailable() {
		return seatsAvailable;
	}



	public void setSeatsAvailable(int seatsAvailable) {
		this.seatsAvailable = seatsAvailable;
	}



	
	
	
}
