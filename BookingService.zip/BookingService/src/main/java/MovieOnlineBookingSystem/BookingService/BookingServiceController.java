package MovieOnlineBookingSystem.BookingService;

import java.util.List;
import java.util.Date;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class BookingServiceController {
	@Autowired	
	private BookingServices service;
	
	
	@PostMapping(value ="/addshow")
	public Show addShow(@RequestBody Show show) {
		return service.addShow(show);
	}
	
	@GetMapping(value = "/Allshows")
	public List<Show> getShows(){
		return service.getAllShows();
	}
	
	@GetMapping(value ="/show/{id}")
	public Show getShowById(@PathVariable("id") Integer id){
        return service.getShow(id);
    }
	
	@GetMapping(path = "/getshow/{movieId}")
	   public List<Show> findShowByMoive(@PathVariable("movieId") Integer movieId){
	       return service.findShowByMoive(movieId);
	   }
	@GetMapping(path = "/getshowbytheatre/{theatreId}")
	   public List<Show> findShowByTheatre(@PathVariable("theatreId") Integer theatreId){
	       return service.findShowByTheatre(theatreId);
	   }

 
    @RequestMapping(method=RequestMethod.PUT, value="/updateshow/{id}")
    public Show updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Show show){
        return service.updateshowDetails(id, show);
    }
    
    @DeleteMapping(path = "/show/{id}")
    public void deleteShow(@PathVariable("id") Integer id){
    service.deleteShow(id);
            
    }
	
    @PostMapping(value ="/addbooking")
    public Booking addBooking(@Valid @RequestBody Booking booking) throws Exception {
        try {
        return service.addBooking(booking);
        }
        catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(), e);
        }
    }
	
	@GetMapping(value ="/Allbooking")
	public List<Booking> getBooking(){
		return service.getBookings();
	}
	
	 @GetMapping(path = "/getbooking/{fromDate}/{toDate}")
	   public List<Booking> getBookings(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate){
	       return service.getBookingsbytdate(fromDate,toDate);
	   }
	
	@DeleteMapping(path = "/cancelbooking/{id}")
    public void cancelBooking(@PathVariable("id") Integer id){
    service.deleteBooking(id);
    
        
    }
	
}
