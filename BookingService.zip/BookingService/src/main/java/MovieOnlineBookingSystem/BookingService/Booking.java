package MovieOnlineBookingSystem.BookingService;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;


@Entity
public class Booking {
	 	@Id
	    @Column(name="bookingid")
	    @GeneratedValue(strategy=GenerationType.IDENTITY)
	    private Integer bookingid;
	    @OneToOne
	    private User userid;
	    @OneToOne
	    private Show showid;	    
	    @NotNull
	    private Integer seatsBooked;    	    
	    private Float amount;	    
	    private String status;
	    
	    
	    
	    
	    
	    
		public Booking() {
			
		}
		
		public Booking(Integer bookingid, User userid, Show showid, Integer seatsBooked, Float amount, String status) {
			super();
			this.bookingid = bookingid;
			this.userid = userid;
			this.showid = showid;
			this.seatsBooked = seatsBooked;
			this.amount = amount;
			this.status = status;
		}

		public Integer getBookingid() {
			return bookingid;
		}
		public void setBookingid(Integer bookingid) {
			this.bookingid = bookingid;
		}
		public User getUserid() {
			return userid;
		}
		public void setUserid(User userid) {
			this.userid = userid;
		}
		public Show getShowid() {
			return showid;
		}
		public void setShowid(Show showid) {
			this.showid = showid;
		}
		public Integer getSeatsBooked() {
			return seatsBooked;
		}
		public void setSeatsBooked(Integer seatsBooked) {
			this.seatsBooked = seatsBooked;
		}
		public Float getAmount() {
			return amount;
		}
		public void setAmount(Float amount) {
			this.amount = amount;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		
	    
	    
	    
}
