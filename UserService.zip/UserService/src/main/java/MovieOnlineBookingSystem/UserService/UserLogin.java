package MovieOnlineBookingSystem.UserService;

public class UserLogin {
	private String name;
	private String password;
		
	
	public UserLogin(String name, String password, String role) {
		super();
		this.name = name;
		this.password = password;
		
	}
	public UserLogin() {
		
	}
	public String getName() {
		return name;
	}
	public String getPassword() {
		return password;
	}
		
	
	
}
