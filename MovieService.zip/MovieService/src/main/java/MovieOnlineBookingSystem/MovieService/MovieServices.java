package MovieOnlineBookingSystem.MovieService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class MovieServices {

	
	@Autowired
	private MovieRepository repository;

	public Movie addMovie(Movie movie) {
		return repository.save(movie);
	}
	
	public List<Movie> getMovies() {
		return (List<Movie>) repository.findAll();
	}

	public Movie getMovie(Integer id) {
		return repository.findById(id).get();
	}

	public List<Movie> getMoviesBymovieName(String moviename) {
		return (List<Movie>) repository.findBymoviename(moviename);
	}
	
	public void deleteByMovieId(Integer id) {
		repository.deleteById(id);
	}
	
	public Movie updateMovie(Integer id,Movie movie) {
		movie.setMovieid(id);
		return repository.save(movie);
	}
}
