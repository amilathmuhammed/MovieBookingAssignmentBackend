package MovieOnlineBookingSystem.MovieService;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MovieServicesController {

	
	@Autowired
	private MovieServices services;
	
	
	@PostMapping(value ="/addmovie")
	public Movie addMovie(@Valid @RequestBody Movie movie){
		return services.addMovie(movie);
	}
	
	@GetMapping(value ="/Movies")
	public List<Movie> getMovies(){
		return services.getMovies();
	}

	@GetMapping(value ="/movie/{id}")
	public Movie getMovieById(@PathVariable("id") Integer id){
		return services.getMovie(id);
	}
	
	
	@RequestMapping(method=RequestMethod.PUT, value="/updatemovie/{id}")
    public Movie updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Movie movie){
        return services.updateMovie(id,movie);
    }

	@GetMapping(value ="/movie/name/{movieName}")
	public List<Movie> getMovieByMovieName(@PathVariable("movieName") String movieName){
		return services.getMoviesBymovieName(movieName);
	}
	
	@DeleteMapping(path = " ")
    public void deleteMovie(@PathVariable("id") Integer id){
      services.deleteByMovieId(id);
    
	}
}
