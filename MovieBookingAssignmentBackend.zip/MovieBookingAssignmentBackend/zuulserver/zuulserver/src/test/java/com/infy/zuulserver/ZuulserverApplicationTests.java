package com.infy.zuulserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
