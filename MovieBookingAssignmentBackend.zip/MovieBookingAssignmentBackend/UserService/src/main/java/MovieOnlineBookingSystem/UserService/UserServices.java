package MovieOnlineBookingSystem.UserService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class UserServices {
	
	@Autowired 
	public UserRepository repository;
	
	
	public List<User> getAllUser(){
		List<User> users= new ArrayList<>();
		 repository.findAll().forEach(users::add);
		
		 return users;
		
	}

	
	public void addUser( User user) {
		user.setRole("user");
		repository.save(user);
	}
	
	
	public void dltUser(String name) {
		repository.deleteById(name);
		
	}
	
	public User updateDetails(User user) {
		user.setRole("user");
		return repository.save(user);
	}

	public User login (UserLogin loginuser) throws Exception
	{         
		User user=null; 
		Optional <User> optuser=repository.findById(loginuser.getName());
	if(optuser.isPresent()) {             
		user=optuser.get();            
		if(user.getPassword().equals(loginuser.getPassword())) {   
			return user;          
			}                         
		else {               
			throw new Exception("Invalid Login");         
			}   
		}          
	else {                
		throw new Exception("Invalid Login");        
		}       
	}
		
	
	
      
}