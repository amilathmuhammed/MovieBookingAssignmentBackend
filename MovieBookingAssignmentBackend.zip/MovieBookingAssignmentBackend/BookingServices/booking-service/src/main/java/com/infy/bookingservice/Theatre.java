package com.infy.bookingservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="theatre")
public class Theatre {
	
		
		@Id
		@Column(name="theatreid")
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private Integer theatreid;
		private String theatrename;
		private String address;
		private Integer seatingcapacity;
		
		
		
		public Theatre() {
			
		}
		public Theatre(Integer theatreid, String theatrename, String address, Integer seatingcapacity) {
			super();
			this.theatreid = theatreid;
			this.theatrename = theatrename;
			this.address = address;
			this.seatingcapacity = seatingcapacity;
		}
		public Integer getTheatreid() {
			return theatreid;
		}
		public void setTheatreid(Integer theatreid) {
			this.theatreid = theatreid;
		}
		public String getTheatrename() {
			return theatrename;
		}
		public void setTheatrename(String theatrename) {
			this.theatrename = theatrename;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public Integer getSeatingcapacity() {
			return seatingcapacity;
		}
		public void setSeatingcapacity(Integer seatingcapacity) {
			this.seatingcapacity = seatingcapacity;
		}
	
	
	
	
}
