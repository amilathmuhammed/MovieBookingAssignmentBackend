package com.infy.bookingservice;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name = "user")
public class User {
        

	@Id
	@Column(name="name")
	private String name;
	private String emailid;
	private String password;
	private String phonenumber;
	private String role;
	
	
	public User() {
		super();
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getPhonenumber() {
		return phonenumber;
	}


	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public User(String name, String emailid, String password, String phonenumber, String role) {
		super();
		this.name = name;
		this.emailid = emailid;
		this.password = password;
		this.phonenumber = phonenumber;
		this.role = role;
	}
		
		
		
	    
}
