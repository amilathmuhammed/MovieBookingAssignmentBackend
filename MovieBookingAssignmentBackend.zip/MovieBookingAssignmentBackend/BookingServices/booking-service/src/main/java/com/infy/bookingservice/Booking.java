package com.infy.bookingservice;

 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

@Entity
public class Booking {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer bookingId;

    @OneToOne
    private User userid;
    
    @OneToOne
    private Show showID;
    
    @NotNull
    private Integer seatsBooked;
    
    
    private Float amount;
    
    private String status;
    
    public Booking() {
        super();
    }

 

    public Integer getBookingId() {
        return bookingId;
    }

 

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

 

    public User getUserid() {
        return userid;
    }

 

    public void setUserid(User userId) {
        this.userid = userId;
    }
    
    public String getStatus() {
        return status;
    }

 

    public void setStatus(String status) {
        this.status = status;
    }

 

    
    public Show getShowID() {
        return showID;
    }

 

    public void setShowID(Show showID) {
        this.showID = showID;
    }

 

    public Integer getSeatsBooked() {
        return seatsBooked;
    }

 

    public void setSeatsBooked(Integer seatsBooked) {
        this.seatsBooked = seatsBooked;
    }

 

    public Float getAmount() {
        return amount;
    }

 

    public void setAmount(Float amount) {
        this.amount = amount;
    }
    
    

 

}