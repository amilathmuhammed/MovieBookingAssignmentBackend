package com.infy.bookingservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "movie")
public class Movie {
	
	
	@Id
	@Column(name = "movieid")        	    
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Integer movieid;
	private String moviename;
	private String language;
	private String category;
	private String duration;
	
	
	
	
	public Movie() {
		
	}
	public Movie(Integer movieid, String moviename, String language, String category, String duration) {
		super();
		this.movieid = movieid;
		this.moviename = moviename;
		this.language = language;
		this.category = category;
		this.duration = duration;
	}
	public Integer getMovieid() {
		return movieid;
	}
	public void setMovieid(Integer movieid) {
		this.movieid = movieid;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	
	
	

}
