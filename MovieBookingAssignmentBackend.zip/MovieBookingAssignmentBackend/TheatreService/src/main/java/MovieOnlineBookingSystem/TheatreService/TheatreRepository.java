package MovieOnlineBookingSystem.TheatreService;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface TheatreRepository extends CrudRepository<Theatre, Integer> {
	public List<Theatre> findByTheatrename(String theatrename);
}
